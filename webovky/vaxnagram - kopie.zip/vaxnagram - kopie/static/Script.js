function loadRandom() {
    fetch('http://127.0.0.1:5000/random-image')
        .then(response => response.json())
        .then(data => {
            if (data.file_url) {
                // Update the image and description
                document.getElementById("titlepost").innerHTML = data.description;
                let imageElement = document.getElementById('resultpost');
                let imageSource = `http://127.0.0.1:5000${data.file_url}`;
                imageElement.src = imageSource;
                document.getElementById("aResultpost").href = imageSource;
                imageElement.style.display = "block";
            } else {
                console.error('No image data received.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error fetching random image.');
        });
}

function checkIfImage(file){
    const imageExtensions = ["jpg", "jpeg", "png", "gif", "bmp", "webp", "svg"];
    const fileExtension = file.name.split(".").pop().toLowerCase();
    return imageExtensions.includes(fileExtension);
}

function gotoUploadImage() {
    const input = document.getElementById('third');
    const file = input.files[0];
    const title = document.getElementById("first").value;


    if(!title || !input.files[0] || !checkIfImage(file)) {
        alert('Please provide a title and select an image.');
        
    }else{
        uploadImage();
    }

}
function uploadImage() {

    const input = document.getElementById('third');
    const file = input.files[0];
    const title = document.getElementById("first").value;


    if (!file) {
        alert('Please select an image to upload.');
        return;
    }

    const formData = new FormData();
    formData.append('image', file);
    formData.append('title', title);
 
    fetch('http://127.0.0.1:5000/upload', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {

        console.log('Success:', data);

        if (data.file_url) {
            document.getElementById("title").innerHTML = data.description;
            let imageElement = document.getElementById('result');
            let imageSource = `http://127.0.0.1:5000${data.file_url}`
            document.getElementById('result').src = imageSource;
            document.getElementById("aResult").href = imageSource;
            imageElement.style.display = "block"; // Ensure image is visible
        } else {
            console.error('No file URL received.');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error uploading image.');
    });
}